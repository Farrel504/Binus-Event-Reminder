package com.example.simple_event_reminder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Reminder {
    private String id; // Unique identifier for Firebase
    private String title;
    private String description;
    private String dueDate;
    private int state;

    public Reminder() {
    }


    public Reminder(String id, String title, String description, String dueDate, int state) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.state = state;
    }


    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDueDate() {
        return dueDate;
    }

    public Date getDueDateAsDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy @ HH:mm", Locale.getDefault());
        try {
            return sdf.parse(dueDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    public int getState() {
        return state;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setState(int state) {
        this.state = state;
    }
}
