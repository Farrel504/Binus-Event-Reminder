package com.example.simple_event_reminder;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UserLogin extends AppCompatActivity {

    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private FirebaseAuth mAuth;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://simple-event-reminder-default-rtdb.asia-southeast1.firebasedatabase.app");
        databaseReference = database.getReference("Users");

        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        TextView signupText = findViewById(R.id.signup_text);

        loginButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (!email.isEmpty() && !password.isEmpty()) {
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(this, task -> {
                            if (task.isSuccessful()) {
                                FirebaseUser user = mAuth.getCurrentUser();
                                Toast.makeText(UserLogin.this, "Login successful", Toast.LENGTH_SHORT).show();
                                Log.d("Login", "Login successful: " + user.getEmail());
                                Intent intent = new Intent(UserLogin.this, UserHome.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(UserLogin.this, "Login failed: Incorrect email or password", Toast.LENGTH_SHORT).show();
                                Log.e("Login", "Login failed", task.getException());
                            }
                        });
            } else {
                Toast.makeText(UserLogin.this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            }
        });

        signupText.setOnClickListener(v -> {
            Intent intent = new Intent(UserLogin.this, UserSignup.class);
            startActivity(intent);
        });
    }
}
