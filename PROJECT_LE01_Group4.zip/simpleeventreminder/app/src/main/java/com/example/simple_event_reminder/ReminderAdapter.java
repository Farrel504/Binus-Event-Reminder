package com.example.simple_event_reminder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ReminderAdapter extends RecyclerView.Adapter<ReminderAdapter.ReminderViewHolder> {


    private List<Reminder> reminderList;
    private final OnReminderClickListener clickListener;
    private final OnReminderLongClickListener longClickListener;

    public ReminderAdapter(List<Reminder> reminderList, OnReminderClickListener clickListener, OnReminderLongClickListener longClickListener) {
        this.reminderList = reminderList;
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    @NonNull
    @Override
    public ReminderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_reminder_adapter, parent, false);
        return new ReminderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReminderViewHolder holder, int position) {
        Reminder reminder = reminderList.get(position);
        holder.title.setText(reminder.getTitle());
        holder.description.setText(reminder.getDescription());
        holder.dueDate.setText(reminder.getDueDate());


        if (reminder.getState() == 1) { // Due but not accepted
            holder.itemView.setBackgroundResource(R.drawable.background_due);
        } else {
            holder.itemView.setBackgroundResource(R.drawable.background_not_due);
        }


        holder.itemView.setOnClickListener(v -> clickListener.onReminderClick(reminder));


        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onReminderLongClick(reminder);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return reminderList == null || reminderList.isEmpty() ? 0 : reminderList.size();
    }

    public interface OnReminderClickListener {
        void onReminderClick(Reminder reminder);
    }

    public interface OnReminderLongClickListener {
        void onReminderLongClick(Reminder reminder);
    }
    static class ReminderViewHolder extends RecyclerView.ViewHolder {
        TextView title, description, dueDate;

        public ReminderViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.reminder_title);
            description = itemView.findViewById(R.id.reminder_description);
            dueDate = itemView.findViewById(R.id.reminder_due_date);
        }
    }
}
