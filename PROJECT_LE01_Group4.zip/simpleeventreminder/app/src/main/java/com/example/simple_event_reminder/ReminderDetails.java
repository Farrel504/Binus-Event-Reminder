package com.example.simple_event_reminder;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ReminderDetails extends AppCompatActivity {

    private TextView titleTextView, descriptionTextView, dueDateTextView;
    private String reminderId;
    private DatabaseReference reminderDatabaseRef;
    private static final int EDIT_REMINDER_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_details);


        titleTextView = findViewById(R.id.reminder_details_title);
        descriptionTextView = findViewById(R.id.reminder_details_description);
        dueDateTextView = findViewById(R.id.reminder_details_due_date);
        Button completeButton = findViewById(R.id.button_complete);


        Intent receivedIntent = getIntent();
        reminderId = receivedIntent.getStringExtra("reminderId");
        String title = receivedIntent.getStringExtra("title");
        String description = receivedIntent.getStringExtra("description");
        String dueDate = receivedIntent.getStringExtra("dueDate");


        Log.d("ReminderDetails", "Received reminderId: " + reminderId);
        Log.d("ReminderDetails", "Received title: " + title);
        Log.d("ReminderDetails", "Received description: " + description);
        Log.d("ReminderDetails", "Received dueDate: " + dueDate);


        reminderDatabaseRef = FirebaseDatabase.getInstance("https://simple-event-reminder-default-rtdb.asia-southeast1.firebasedatabase.app")
                .getReference("Users")
                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                .child("reminders");


        updateReminderDetails(title, description, dueDate);


        ImageButton backArrow = findViewById(R.id.back_arrow);
        backArrow.setOnClickListener(v -> onBackPressed());


        ImageButton editButton = findViewById(R.id.edit_button);
        editButton.setOnClickListener(v -> {
            Intent editIntent = new Intent(ReminderDetails.this, EditReminder.class);


            Log.d("ReminderDetails", "Passing reminderId to EditReminder: " + reminderId);
            editIntent.putExtra("reminderId", reminderId);
            editIntent.putExtra("title", title);
            editIntent.putExtra("description", description);
            editIntent.putExtra("dueDate", dueDate);

            startActivityForResult(editIntent, EDIT_REMINDER_REQUEST_CODE);
        });


        reminderDatabaseRef.child(reminderId).child("state").get().addOnSuccessListener(snapshot -> {
            if (snapshot.exists()) {
                int currentState = snapshot.getValue(Integer.class);


                if (currentState == 2) {
                    editButton.setVisibility(ImageButton.GONE);
                    completeButton.setText("Revert");
                    completeButton.setOnClickListener(v -> revertReminderState());
                } else {
                    completeButton.setText("Complete");
                    completeButton.setOnClickListener(v -> updateReminderStateToCompleted());
                }
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(ReminderDetails.this, "Failed to fetch reminder state", Toast.LENGTH_SHORT).show();
            Log.e("ReminderDetails", "Failed to fetch state: " + e.getMessage());
        });
    }

    private void updateReminderDetails(String title, String description, String dueDate) {
        titleTextView.setText(title);
        descriptionTextView.setText(description);
        dueDateTextView.setText(dueDate);
    }

    private void updateReminderStateToCompleted() {
        if (reminderId == null) {
            Toast.makeText(this, "Invalid reminder ID", Toast.LENGTH_SHORT).show();
            return;
        }


        reminderDatabaseRef.child(reminderId).child("state").get().addOnSuccessListener(snapshot -> {
            if (snapshot.exists()) {
                int currentState = snapshot.getValue(Integer.class);

                if (currentState == 1) {
                    // Update the state to 2 (Completed) if the current state is 1
                    reminderDatabaseRef.child(reminderId).child("state").setValue(2)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(ReminderDetails.this, "Reminder marked as completed", Toast.LENGTH_SHORT).show();
                                finish();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(ReminderDetails.this, "Failed to update reminder state", Toast.LENGTH_SHORT).show();
                                Log.e("ReminderDetails", "Failed to update state: " + e.getMessage());
                            });
                } else if (currentState == 2) {
                    // If state is already completed
                    Toast.makeText(ReminderDetails.this, "This reminder is already completed", Toast.LENGTH_SHORT).show();
                } else if (currentState == 0) {
                    // If state not yet even due
                    Toast.makeText(ReminderDetails.this, "This reminder is not yet due", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(ReminderDetails.this, "Failed to fetch reminder state", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(ReminderDetails.this, "Failed to fetch reminder state", Toast.LENGTH_SHORT).show();
            Log.e("ReminderDetails", "Failed to fetch state: " + e.getMessage());
        });
    }

    private void revertReminderState() {
        if (reminderId == null) {
            Toast.makeText(this, "Invalid reminder ID", Toast.LENGTH_SHORT).show();
            return;
        }

        // Turn back state into 1 if only the current state is 2
        reminderDatabaseRef.child(reminderId).child("state").get().addOnSuccessListener(snapshot -> {
            if (snapshot.exists()) {
                int currentState = snapshot.getValue(Integer.class);

                if (currentState == 2) {

                    reminderDatabaseRef.child(reminderId).child("state").setValue(1)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(ReminderDetails.this, "Reminder reverted to due", Toast.LENGTH_SHORT).show();
                                finish(); // Close the activity after reverting
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(ReminderDetails.this, "Failed to revert reminder state", Toast.LENGTH_SHORT).show();
                                Log.e("Reminder", "Failed to revert state: " + e.getMessage());
                            });
                } else {
                    Toast.makeText(ReminderDetails.this, "This reminder is not completed yet", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(ReminderDetails.this, "Failed to fetch reminder state", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(ReminderDetails.this, "Failed to fetch reminder state", Toast.LENGTH_SHORT).show();
            Log.e("Reminder", "Failed to fetch state: " + e.getMessage());
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == EDIT_REMINDER_REQUEST_CODE && resultCode == RESULT_OK && data != null) {

            String updatedTitle = data.getStringExtra("title");
            String updatedDescription = data.getStringExtra("description");
            String updatedDueDate = data.getStringExtra("dueDate");

            Log.d("Reminder", "Updated title: " + updatedTitle);
            Log.d("Reminder", "Updated description: " + updatedDescription);
            Log.d("Reminder", "Updated dueDate: " + updatedDueDate);


            updateReminderDetails(updatedTitle, updatedDescription, updatedDueDate);
        }
    }
}
