package com.example.simple_event_reminder;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;
import java.util.Calendar;

// JANGAN TARO EMOJI, RUSAKIN SEMUANYA, BIKIN AKUN BARU JIKA TERLANJUR

public class CreateReminder extends AppCompatActivity {


    private TextView cancelButton;
    private EditText titleInput, descriptionInput;
    private Button saveButton, dueDateInput;
    private DatabaseReference databaseRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_reminder);

        titleInput = findViewById(R.id.input_title);
        descriptionInput = findViewById(R.id.input_description);
        dueDateInput = findViewById(R.id.input_due_date);
        saveButton = findViewById(R.id.btn_save_reminder);
        cancelButton = findViewById(R.id.text_cancel);
        mAuth = FirebaseAuth.getInstance();
        String userId = mAuth.getCurrentUser().getUid();

        databaseRef = FirebaseDatabase.getInstance("https://simple-event-reminder-default-rtdb.asia-southeast1.firebasedatabase.app")
                .getReference("Users").child(userId).child("reminders");


        dueDateInput.setFocusable(false);
        dueDateInput.setClickable(true);
        dueDateInput.setOnClickListener(v -> showDateTimePickerDialog());


        saveButton.setOnClickListener(v -> saveReminder());


        cancelButton.setOnClickListener(v -> cancelReminder());
    }

    private void showDateTimePickerDialog() {

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(
                (view, year1, monthOfYear, dayOfMonth) -> {

                    showTimePickerDialog(year1, monthOfYear, dayOfMonth);
                },
                year, month, day
        );

        datePickerDialog.setMinDate(calendar);
        datePickerDialog.show(getSupportFragmentManager(), "Datepickerdialog");
    }


    private void showTimePickerDialog(int year, int month, int day) {
        Calendar current = Calendar.getInstance();

        TimePickerDialog timePickerDialog = TimePickerDialog.newInstance(
                (view, hourOfDay, minute1, second) -> {
                    Calendar selected = Calendar.getInstance();
                    selected.set(year, month, day, hourOfDay, minute1);


                    if (selected.before(current)) {
                        Toast.makeText(CreateReminder.this, "Select a future time", Toast.LENGTH_SHORT).show();
                    } else {
                        String formattedDateTime = String.format("%02d/%02d/%04d @ %02d:%02d", day, month + 1, year, hourOfDay, minute1);
                        dueDateInput.setText(formattedDateTime);
                    }
                },
                current.get(Calendar.HOUR_OF_DAY),
                current.get(Calendar.MINUTE),
                true
        );

        timePickerDialog.show(getSupportFragmentManager(), "Timepickerdialog");
    }

    private void saveReminder() {
        String title = titleInput.getText().toString().trim();
        String description = descriptionInput.getText().toString().trim();
        String dueDate = dueDateInput.getText().toString().trim();

        if (title.isEmpty() || description.isEmpty() || dueDate.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        String id = databaseRef.push().getKey();
        int state = 0;

        Reminder reminder = new Reminder(id, title, description, dueDate, state);

        databaseRef.child(id).setValue(reminder).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(CreateReminder.this, "Reminder saved successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(CreateReminder.this, "Failed to save reminder", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void cancelReminder() {
        finish();
    }


}
