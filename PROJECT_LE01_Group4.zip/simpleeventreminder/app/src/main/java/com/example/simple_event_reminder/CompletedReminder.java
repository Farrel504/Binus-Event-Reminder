package com.example.simple_event_reminder;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CompletedReminder extends AppCompatActivity {

    private final Handler handler = new Handler();
    private static final long REFRESH_INTERVAL = 60000;
    private Runnable periodicUpdater;
    private RecyclerView recyclerView;
    private ReminderAdapter adapter;
    private List<Reminder> reminderList;
    private DatabaseReference reminderDatabaseRef;
    private FirebaseAuth mAuth;
    private ImageView homeIcon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed_reminder);


        mAuth = FirebaseAuth.getInstance();
        String userId = mAuth.getCurrentUser().getUid();
        reminderDatabaseRef = FirebaseDatabase.getInstance("https://simple-event-reminder-default-rtdb.asia-southeast1.firebasedatabase.app")
                .getReference("Users").child(userId).child("reminders");


        recyclerView = findViewById(R.id.recycler_view_completed);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        reminderList = new ArrayList<>();
        adapter = new ReminderAdapter(reminderList, reminder -> {

            Intent intent = new Intent(CompletedReminder.this, ReminderDetails.class);
            intent.putExtra("reminderId", reminder.getId());
            intent.putExtra("title", reminder.getTitle());
            intent.putExtra("description", reminder.getDescription());
            intent.putExtra("dueDate", reminder.getDueDate());
            startActivity(intent);
        }, reminder -> {

            new AlertDialog.Builder(CompletedReminder.this)
                    .setTitle("Delete Reminder")
                    .setMessage("Are you sure you want to delete this reminder?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        reminderDatabaseRef.child(reminder.getId()).removeValue()
                                .addOnSuccessListener(aVoid -> Toast.makeText(CompletedReminder.this, "Reminder deleted", Toast.LENGTH_SHORT).show())
                                .addOnFailureListener(e -> Toast.makeText(CompletedReminder.this, "Failed to delete reminder", Toast.LENGTH_SHORT).show());
                    })
                    .setNegativeButton("No", null)
                    .show();
        });

        recyclerView.setAdapter(adapter);


        reminderDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                reminderList.clear();
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Reminder reminder = dataSnapshot.getValue(Reminder.class);
                    if (reminder != null && reminder.getState() == 2) {  // Only add completed reminders
                        reminderList.add(reminder);
                    }
                }

                sortRemindersByDueDate();
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CompletedReminder.this, "Failed to fetch reminders", Toast.LENGTH_SHORT).show();
            }
        });


        homeIcon = findViewById(R.id.home_icon);
        homeIcon.setOnClickListener(v -> {
            Intent homeIntent = new Intent(CompletedReminder.this, UserHome.class);
            startActivity(homeIntent);
            finish();
        });

        setupPeriodicUpdater();
    }

    private void setupPeriodicUpdater() {
        periodicUpdater = () -> {
            updateReminderStates();
            handler.postDelayed(periodicUpdater, REFRESH_INTERVAL);
        };
        handler.post(periodicUpdater);
    }

    private void updateReminderStates() {
        for (Reminder reminder : reminderList) {
            int newState = calculateReminderState(reminder);
            if (reminder.getState() != newState) {
                reminder.setState(newState);

                reminderDatabaseRef.child(reminder.getId()).child("state").setValue(newState);
            }
        }

        sortRemindersByDueDate();
        adapter.notifyDataSetChanged();
    }

    private void sortRemindersByDueDate() {
        Collections.sort(reminderList, (reminder1, reminder2) -> {
            Date date1 = reminder1.getDueDateAsDate();
            Date date2 = reminder2.getDueDateAsDate();
            return date1.compareTo(date2);
        });
    }

    private int calculateReminderState(Reminder reminder) {
        String dueDate = reminder.getDueDate();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy @ HH:mm", Locale.getDefault());
        try {
            Date due = sdf.parse(dueDate);
            Date now = new Date();


            if (reminder.getState() == 2) {
                return 2; // Completed
            }


            if (now.before(due)) {
                return 0; // Not Due
            } else {
                return 1; // Due but Not Completed
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return reminder.getState();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(periodicUpdater);
    }
}
