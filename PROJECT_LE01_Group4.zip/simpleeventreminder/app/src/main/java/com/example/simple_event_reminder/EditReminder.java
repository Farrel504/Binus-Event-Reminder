package com.example.simple_event_reminder;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditReminder extends AppCompatActivity {

    private EditText inputTitle, inputDescription;
    private Button inputDueDate, btnSaveReminder;
    private String reminderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_reminder);


        inputTitle = findViewById(R.id.input_title);
        inputDescription = findViewById(R.id.input_description);
        inputDueDate = findViewById(R.id.input_due_date);
        btnSaveReminder = findViewById(R.id.btn_save_reminder);
        TextView textCancel = findViewById(R.id.text_cancel);

        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String description = intent.getStringExtra("description");
        String dueDate = intent.getStringExtra("dueDate");
        reminderId = intent.getStringExtra("reminderId");
        Log.d("ReminderDetails", "Received reminderId: " + reminderId);


        if (title != null) inputTitle.setText(title);
        if (description != null) inputDescription.setText(description);
        if (dueDate != null) inputDueDate.setText(dueDate);


        textCancel.setOnClickListener(v -> finish());


        inputDueDate.setOnClickListener(v -> showDateTimePicker());


        btnSaveReminder.setOnClickListener(v -> saveEditedReminder());
    }

    private void showDateTimePicker() {
        Calendar calendar = Calendar.getInstance();


        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, (timeView, hourOfDay, minute) -> {
                String selectedDateTime = String.format("%02d/%02d/%04d @ %02d:%02d", dayOfMonth, month + 1, year, hourOfDay, minute);
                inputDueDate.setText(selectedDateTime);
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true);

            timePickerDialog.show();
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));


        datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());

        datePickerDialog.show();
    }


    private void saveEditedReminder() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(EditReminder.this, "No authenticated user", Toast.LENGTH_SHORT).show();
            return;
        }

        if (reminderId == null) {
            Toast.makeText(EditReminder.this, "Reminder ID is null", Toast.LENGTH_SHORT).show();
            return;
        }


        String updatedTitle = inputTitle.getText().toString().trim();
        String updatedDescription = inputDescription.getText().toString().trim();
        String updatedDueDate = inputDueDate.getText().toString().trim();

        if (updatedTitle.isEmpty()) {
            inputTitle.setError("Title cannot be empty");
            return;
        }


        DatabaseReference reminderRef = FirebaseDatabase.getInstance("https://simple-event-reminder-default-rtdb.asia-southeast1.firebasedatabase.app")
                .getReference("Users")
                .child(user.getUid())
                .child("reminders")
                .child(reminderId);

        Map<String, Object> updatedData = new HashMap<>();
        updatedData.put("title", updatedTitle);
        updatedData.put("description", updatedDescription);
        updatedData.put("dueDate", updatedDueDate);


        reminderRef.updateChildren(updatedData).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(EditReminder.this, "Reminder updated", Toast.LENGTH_SHORT).show();


                Intent resultIntent = new Intent();
                resultIntent.putExtra("title", updatedTitle);
                resultIntent.putExtra("description", updatedDescription);
                resultIntent.putExtra("dueDate", updatedDueDate);
                resultIntent.putExtra("reminderId", reminderId);
                setResult(RESULT_OK, resultIntent);

                finish();
            } else {
                Toast.makeText(EditReminder.this, "Failed to update reminder", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(e -> {
            Toast.makeText(EditReminder.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        });
    }

}
