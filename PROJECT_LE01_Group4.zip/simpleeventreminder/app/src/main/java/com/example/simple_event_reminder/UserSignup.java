package com.example.simple_event_reminder;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class UserSignup extends AppCompatActivity {

    private EditText usernameEditText, emailEditText, passwordEditText;
    private Button signupButton;
    private FirebaseAuth mAuth;
    private TextView loginLink;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup);

        mAuth = FirebaseAuth.getInstance();
        FirebaseDatabase database = FirebaseDatabase.getInstance("https://simple-event-reminder-default-rtdb.asia-southeast1.firebasedatabase.app");
        databaseReference = database.getReference("Users");

        usernameEditText = findViewById(R.id.username);
        emailEditText = findViewById(R.id.email);
        passwordEditText = findViewById(R.id.password);
        signupButton = findViewById(R.id.signupbutton);
        loginLink = findViewById(R.id.loginlink);

        signupButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (username.isEmpty()) {
                Toast.makeText(UserSignup.this, "Please enter a username", Toast.LENGTH_SHORT).show();
                return;
            }
            if (email.isEmpty()) {
                Toast.makeText(UserSignup.this, "Please enter an email address", Toast.LENGTH_SHORT).show();
                return;
            }
            if (password.isEmpty()) {
                Toast.makeText(UserSignup.this, "Please enter a password", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(UserSignup.this, "Account created successfully!", Toast.LENGTH_SHORT).show();

                            String userId = mAuth.getCurrentUser().getUid();

                            User user = new User(username, email);
                            databaseReference.child(userId).setValue(user)
                                    .addOnCompleteListener(dbTask -> {
                                        if (dbTask.isSuccessful()) {
                                            Toast.makeText(UserSignup.this, "Successfully saved user data", Toast.LENGTH_SHORT).show();

                                            Intent intent = new Intent(UserSignup.this, UserLogin.class);
                                            startActivity(intent);
                                            finish();
                                        } else {
                                            Toast.makeText(UserSignup.this, "Failed to save user data", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                                Toast.makeText(UserSignup.this, "This email is already in use", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(UserSignup.this, "Account creation failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        });

        loginLink.setOnClickListener(v -> {
            Intent intent = new Intent(UserSignup.this, UserLogin.class);
            startActivity(intent);
            finish();
        });
    }

    public static class User {
        public String username;
        public String email;

        public User() {
        }

        public User(String username, String email) {
            this.username = username;
            this.email = email;
        }
    }
}
